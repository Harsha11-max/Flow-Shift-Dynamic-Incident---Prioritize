const test = require('node:test');
const assert = require('node:assert/strict');
const { makeTicket, calculateScore, buildPlan, createDemoTickets, MINUTE } = require('../engine.js');

const NOW = Date.parse('2026-01-01T12:00:00Z');
function ticket(id, { urgency = 3, impact = 3, slaMinutes = 60, age = 0 } = {}) {
  return makeTicket({ title: `Test ${id}`, category: 'Other', urgency, impact, slaMinutes }, NOW - age * MINUTE, id);
}

test('high-urgency emergency outranks a routine incident', () => {
  const routine = ticket('R', { urgency: 1, impact: 1 });
  const emergency = ticket('E', { urgency: 5, impact: 5, slaMinutes: 15 });
  const plan = buildPlan([routine, emergency], 1, NOW);
  assert.equal(plan.active[0].id, 'E');
  assert.equal(plan.active[0].status, 'assigned');
  assert.equal(plan.active[1].status, 'waiting');
});

test('scores rise as an incident waits longer', () => {
  const old = ticket('A');
  assert.ok(calculateScore(old, NOW + 30 * MINUTE).total > calculateScore(old, NOW).total);
});

test('missed deadlines are escalated', () => {
  const t = ticket('A', { slaMinutes: 15 });
  const early = calculateScore(t, NOW);
  const late = calculateScore(t, NOW + 16 * MINUTE);
  assert.equal(late.deadlineState, 'overdue');
  assert.equal(late.deadlinePoints, 40);
  assert.ok(late.total > early.total);
});

test('reducing team capacity moves lower-ranked work back to waiting', () => {
  const cases = [ticket('A'), ticket('B'), ticket('C')];
  const normal = buildPlan(cases, 2, NOW);
  const reduced = buildPlan(cases, 1, NOW);
  assert.equal(normal.stats.assigned, 2);
  assert.equal(reduced.stats.assigned, 1);
  assert.equal(reduced.stats.waiting, 2);
});

test('resolving an assigned incident frees its team for another case', () => {
  const a = ticket('A', { urgency: 5 });
  const b = ticket('B', { urgency: 2 });
  let plan = buildPlan([a, b], 1, NOW);
  assert.equal(plan.active[0].id, 'A');
  a.resolvedAt = NOW;
  plan = buildPlan([a, b], 1, NOW);
  assert.equal(plan.active[0].id, 'B');
  assert.equal(plan.active[0].status, 'assigned');
  assert.equal(plan.stats.resolved, 1);
});

test('earlier deadline breaks equal-score ties', () => {
  const a = ticket('A', { slaMinutes: 60 });
  const b = ticket('B', { slaMinutes: 45 });
  // At time zero, the 45-minute deadline has a bonus of 10; adjust severity for true tie via waiting.
  const x = ticket('X', { slaMinutes: 120 });
  const y = ticket('Y', { slaMinutes: 180 });
  const plan = buildPlan([y, x], 1, NOW);
  assert.equal(plan.active[0].id, 'X');
  assert.equal(plan.active[0].score.total, plan.active[1].score.total);
  assert.ok(calculateScore(b, NOW).total >= calculateScore(a, NOW).total);
});

test('scoring does not modify the original ticket records', () => {
  const original = ticket('A');
  const before = JSON.stringify(original);
  buildPlan([original], 1, NOW);
  assert.equal(JSON.stringify(original), before);
});

test('new reports reject invalid inputs', () => {
  assert.throws(() => makeTicket({ title: '', urgency: 3, impact: 3, slaMinutes: 60 }, NOW, 'X'));
  assert.throws(() => makeTicket({ title: 'Incident', urgency: 6, impact: 3, slaMinutes: 60 }, NOW, 'X'));
  assert.throws(() => makeTicket({ title: 'Incident', urgency: 3, impact: 3, slaMinutes: 7 }, NOW, 'X'));
});

test('demo starts with exactly seven open incidents', () => {
  const demo = createDemoTickets(NOW);
  assert.equal(demo.length, 7);
  assert.equal(buildPlan(demo, 2, NOW).stats.active, 7);
});

test('no available responders means all active incidents wait', () => {
  const plan = buildPlan([ticket('A'), ticket('B')], 0, NOW);
  assert.equal(plan.stats.assigned, 0);
  assert.equal(plan.stats.waiting, 2);
});
